# Raycast Game

a raycsting game built using the engine techniques of Wolfenstien 3D, stilized like DOOM.
<br><br>
built using pygame, following this [tutorial](https://youtu.be/ECqUrT7IdqQ) by Coder Space. you can find his repo [here](https://github.com/StanislavPetrovV/DOOM-style-Game)
<br><br>
sprites taken from [Sprite Database](https://spritedatabase.net/game/760)
<hr>
I intend to take what was learned here and create my own game eventually. this is just a tutorial project.
