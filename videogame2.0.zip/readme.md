This is an attempt to convert the javascript ray casting example found here:

http://www.playfuljs.com/a-first-person-engine-in-265-lines/

At the moment it is a very direct translation from the javascript, but current results are somewhat... uninspiring.

~~I maintain about 8 frames per second.  I'm hoping to find some way to combat this.~~

Edit: 
The frame rate has been brought up to about 20 fps through various simplifications and changes.  
Still not amazing, but much better.

-Mek